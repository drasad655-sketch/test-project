import { config } from 'dotenv';
config();

import '@/ai/flows/detect-supply-chain-anomalies.ts';
import '@/ai/flows/detect-inventory-anomalies.ts';