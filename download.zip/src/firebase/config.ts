export const firebaseConfig = {
  "projectId": "studio-4955737832-a76c5",
  "appId": "1:967948677523:web:33a28563cea7edadb4f866",
  "apiKey": "AIzaSyC-jNzGQqJWrAtTUDPznsMxNagRDkjvIsE",
  "authDomain": "studio-4955737832-a76c5.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "967948677523"
};
